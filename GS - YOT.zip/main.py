import cv2
import mediapipe as mp
import numpy as np
import csv
from datetime import datetime
import os

# ============ CONFIGURAÇÕES ============
LIMIAR_APAGAO = 40
REGIAO = "São Paulo - Zona Sul"
LOG_PATH = 'alertas_log.csv'
REPORT_PATH = 'relatorio_apagoes.txt'
VIDEO_PATH = 'assets/videos/teste_gestos.mp4'  # Ou 0 para webcam
# =======================================

# Inicializa MediaPipe
mp_hands = mp.solutions.hands
mp_drawing = mp.solutions.drawing_utils
hands = mp_hands.Hands(
    max_num_hands=1,
    min_detection_confidence=0.7,
    min_tracking_confidence=0.6
)

# Cria arquivos de log se não existirem
if not os.path.exists(LOG_PATH):
    with open(LOG_PATH, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['data_hora', 'aviso', 'luminosidade', 'regiao', 'duracao'])

# Inicializa variáveis para relatório
apagao_em_andamento = False
inicio_apagao = None
total_apagoes = 0
dados_apagao = []


def medir_luminosidade(frame):
    cinza = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    return int(np.mean(cinza))


def is_hand_open(landmarks):
    dedos = {
        "indicador": [8, 6, 5],
        "medio": [12, 10, 9],
        "anelar": [16, 14, 13],
        "mindinho": [20, 18, 17]
    }

    dedos_abertos = 0
    for nome, (ponta, meio, base) in dedos.items():
        if landmarks.landmark[ponta].y < landmarks.landmark[meio].y < landmarks.landmark[base].y:
            dedos_abertos += 1
    return dedos_abertos >= 3


def gerar_relatorio():
    with open(REPORT_PATH, 'w') as f:
        f.write("=== RELATÓRIO DE APAGÕES DETECTADOS ===\n\n")
        f.write(f"Data da geração: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"Região monitorada: {REGIAO}\n")
        f.write(f"Total de apagões detectados: {total_apagoes}\n\n")

        f.write("Detalhes dos apagões:\n")
        f.write("Data/Hora Início | Duração (s) | Luminosidade Média\n")
        f.write("-------------------------------------------------\n")

        for evento in dados_apagao:
            data_hora, duracao, luminosidade = evento
            f.write(f"{data_hora} | {duracao:.1f} | {luminosidade}\n")

        f.write("\n=== FIM DO RELATÓRIO ===")


cap = cv2.VideoCapture(VIDEO_PATH)

try:
    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break

        frame = cv2.flip(frame, 1)
        frame = cv2.resize(frame, (640, 480))
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

        brilho = medir_luminosidade(frame)
        current_time = datetime.now()

        results = hands.process(rgb)
        cv2.putText(frame, f"Luminosidade: {brilho}", (10, 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)

        if results.multi_hand_landmarks:
            for hand_landmarks in results.multi_hand_landmarks:
                mp_drawing.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)

                if is_hand_open(hand_landmarks) and brilho < LIMIAR_APAGAO:
                    if not apagao_em_andamento:
                        apagao_em_andamento = True
                        inicio_apagao = current_time
                        total_apagoes += 1

                    cv2.putText(frame, "APAGAO DETECTADO!", (10, 60),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 200, 255), 2)
                else:
                    if apagao_em_andamento:
                        # Finaliza o apagão e registra
                        duracao = (current_time - inicio_apagao).total_seconds()
                        dados_apagao.append((
                            inicio_apagao.strftime("%Y-%m-%d %H:%M:%S"),
                            duracao,
                            brilho
                        ))

                        with open(LOG_PATH, 'a', newline='') as f:
                            writer = csv.writer(f)
                            writer.writerow([
                                inicio_apagao.strftime("%Y-%m-%d %H:%M:%S"),
                                'Alerta de apagão confirmado',
                                brilho,
                                REGIAO,
                                f"{duracao:.1f}s"
                            ])

                        apagao_em_andamento = False

        cv2.imshow("PowerWatch - Detecção de Apagão", frame)
        if cv2.waitKey(30) & 0xFF == 27:
            break

finally:
    # Ao finalizar, gera o relatório completo
    gerar_relatorio()
    cap.release()
    cv2.destroyAllWindows()
    print(f"Relatório gerado em: {REPORT_PATH}")